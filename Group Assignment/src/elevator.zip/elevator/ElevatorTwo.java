package elevator;

public class ElevatorTwo extends Thread {
    private final MutEx mutex;
    private int currentFloor;
    private final ElevatorGUI gui;

    public ElevatorTwo(MutEx m, int startingFloor, ElevatorGUI gui) {
        this.mutex = m;
        this.currentFloor = startingFloor;
        this.gui = gui;
    }

    @Override
    public void run() {
        while (true) {
            try {
                if (mutex.isEnd()) {
                    moveToFloor(9); // Return to default floor
                    System.out.println("Elevator Two is shutting down at default floor 10.");
                    break;
                }

                Integer nextFloor = mutex.getNextDownFloorForTwo();
                if (nextFloor != null) {
                    moveToFloor(nextFloor);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void moveToFloor(int targetFloor) throws InterruptedException {
        System.out.println("Elevator Two moving from " + currentFloor + " to " + targetFloor);
        gui.updateElevatorPosition(2, currentFloor);
        int delay; 
        if(targetFloor > currentFloor){
            delay = (targetFloor - currentFloor) * 500 ;
            Thread.sleep(delay);
        }else{
            delay = (currentFloor - targetFloor) * 500 ;
            Thread.sleep(delay);
        }       
        currentFloor = targetFloor;
        gui.updateElevatorPosition(2, currentFloor);
        System.out.println("Elevator Two reached floor " + currentFloor);
    }
}
