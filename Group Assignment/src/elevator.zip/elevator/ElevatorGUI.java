package elevator;

import javax.swing.*;

public class ElevatorGUI extends JFrame {
    private ElevatorPanel elevatorPanel;
    private static final int NUM_ELEVATORS = 2; // Number of elevators in the simulation

    public ElevatorGUI() {
        setTitle("Elevator Simulation");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Initialize elevator panel with the number of elevators
        elevatorPanel = new ElevatorPanel(NUM_ELEVATORS);
        add(elevatorPanel);

        pack(); // Adjust frame size to fit components
        setVisible(true); // Display the frame
    }

    // Update the position of an elevator (floor number)
    public void updateElevatorPosition(int elevatorId, int floor) {
        SwingUtilities.invokeLater(() -> elevatorPanel.updateElevatorPosition(elevatorId, floor));
    }

    // Set the idle state of an elevator
    public void setIdleState(int elevatorId, boolean isIdle) {
        SwingUtilities.invokeLater(() -> elevatorPanel.setIdleState(elevatorId, isIdle));
    }

    // Check if all elevators are idle
    public boolean allElevatorsIdle() {
        return elevatorPanel.allElevatorsIdle();
    }
}