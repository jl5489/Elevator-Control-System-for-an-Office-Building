package elevator;

public class ElevatorOne extends Thread {
    private final MutEx mutex;
    private int currentFloor;
    private final ElevatorGUI gui;

    public ElevatorOne(MutEx m, int startingFloor, ElevatorGUI gui) {
        this.mutex = m;
        this.currentFloor = startingFloor;
        this.gui = gui;
    }

    @Override
    public void run() {
        while (true) {
            try {
                if (mutex.isEnd()) {
                    moveToFloor(0); // Return to default floor
                    System.out.println("Elevator One is shutting down at default floor 1.");
                    break;
                }

                Integer nextFloor = mutex.getNextUpFloorForOne();
                if (nextFloor != null) {
                    moveToFloor(nextFloor);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void moveToFloor(int targetFloor) throws InterruptedException {
        System.out.println("Elevator One moving from " + currentFloor + " to " + targetFloor);
        gui.updateElevatorPosition(1, currentFloor);
        int delay; 
        if(targetFloor > currentFloor){
            delay = (targetFloor - currentFloor) * 500 ;
            Thread.sleep(delay);
        }else{
            delay = (currentFloor - targetFloor) * 500 ;
            Thread.sleep(delay);
        }        
        currentFloor = targetFloor;
        gui.updateElevatorPosition(1, currentFloor);
        System.out.println("Elevator One reached floor " + currentFloor);
    }
}